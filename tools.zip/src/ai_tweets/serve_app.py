from ai_tweets.api import app
